<?php

namespace App\Models\Payroll;

use Illuminate\Database\Eloquent\Model;

class SalaryPayment extends Model
{
    //
}
