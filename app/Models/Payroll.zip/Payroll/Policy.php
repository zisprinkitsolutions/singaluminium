<?php

namespace App\Models\Payroll;

use Illuminate\Database\Eloquent\Model;

class Policy extends Model
{
    protected $guarded = [];

}
